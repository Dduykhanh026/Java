package Bean;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

import Bean.Nguoi;

public class Chay {

	public static void main(String[] args) {
		try {
			SimpleDateFormat dd = new SimpleDateFormat("dd/MM/yyyy");
			ArrayList<Nguoi> ds = new ArrayList<Nguoi>();
			Nguoi n1 = new Nguoi("Khanh", true, dd.parse("12/08/1993"));
			Nguoi n2 = new Nguoi("Nhan", false, dd.parse("29/03/2004"));
			Nguoi n3 = new Nguoi("Tran", false, dd.parse("24/10/2004"));
			ds.add(n1);
			ds.add(n2);
			ds.add(n3);
			//Hiển thị những người trên 30 tuổi
			for(Nguoi person:ds) {
				if(person.TinhTuoi() >30 )
					System.out.println(person.toString());
			}
			//Thống kê nam nữ
			int cntnam = 0;
			int cntnu = 0;
			for(Nguoi person:ds) {
				if(person.isGioitinh()==true)
					cntnam++;
				else cntnu++;
			}
			System.out.println(cntnam + " nam");
			System.out.println(cntnu+ " nu");
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
