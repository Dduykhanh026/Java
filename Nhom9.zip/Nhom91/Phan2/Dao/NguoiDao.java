package Dao;
import java.text.SimpleDateFormat;
import java.util.ArrayList;


import Bean.Nguoi;

public class NguoiDao {
	
	public ArrayList<Nguoi> getds() throws Exception {
		SimpleDateFormat dd = new SimpleDateFormat("dd/MM/yyyy");
		Nguoi n1 = new Nguoi("Khanh", true, dd.parse("12/08/1993"));
		Nguoi n2 = new Nguoi("Nhan", false, dd.parse("29/03/2004"));
		Nguoi n3 = new Nguoi("Tran", false, dd.parse("24/10/2004"));
		ArrayList<Nguoi> ds = new ArrayList<Nguoi>();
		ds.add(n1);
		ds.add(n2);
		ds.add(n3);
		return ds;
	}
}
