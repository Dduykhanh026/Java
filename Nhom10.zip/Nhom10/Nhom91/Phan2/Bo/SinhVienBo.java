package Bo;

import java.util.ArrayList;

import Bean.SinhVienBean;
import Dao.NguoiDao;

public class SinhVienBo {
	NguoiDao ndao = new NguoiDao();
	ArrayList<SinhVienBean> ds = new ArrayList<SinhVienBean>();
	public ArrayList<SinhVienBean> getsv() throws Exception{
		ds = ndao.getsv();
		return ds;
	}
	//Liệt kê các chức năng của sinh viên
	//Điểm DTB của tất cả sinh viên
	public double TbcDtb()throws Exception {
		double s = 0;
		for(SinhVienBean sv : ds)
			s= s+sv.getDtb();
		return s/ds.size();
	}
	
}
