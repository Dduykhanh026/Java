package Bean;

import java.util.Date;
import java.text.SimpleDateFormat;

public class Nguoi {
		private String hoten;
		private boolean gioitinh;
		private Date ngaysinh;
		
		public Nguoi() {
			super();
			
		}
		
		public Nguoi(String hoten, boolean gioitinh, Date ngaysinh) {
			super();
			this.hoten = hoten;
			this.gioitinh = gioitinh;
			this.ngaysinh = ngaysinh;
		}

		public String getHoten() {
			return hoten;
		}
		public void setHoten(String hoten) {
			this.hoten = hoten;
		}
		public boolean isGioitinh() {
			return gioitinh;
		}
		public void setGioitinh(boolean gioitinh) {
			this.gioitinh = gioitinh;
		}
		public Date getNgaysinh() {
			return ngaysinh;
		}
		public void setNgaysinh(Date ngaysinh) {
			this.ngaysinh = ngaysinh;
		}
		public int TinhTuoi(){
			//Tự làm
//	        Date date = new Date();
//	        SimpleDateFormat simpleDateFormat = new SimpleDateFormat();
//	        simpleDateFormat.applyPattern("yyyy");
//	        String yearnow = simpleDateFormat.format(date);
//	        String namsinh = simpleDateFormat.format(ngaysinh);
//	        int tuoi = Integer.parseInt(yearnow) - Integer.parseInt(namsinh);
//	        return tuoi;
			
			//Cách của thầy
			SimpleDateFormat dd = new SimpleDateFormat("dd/MM/yyyy");
			String ns = dd.format(ngaysinh);
			int namsinh = Integer.parseInt(ns.split("[/]")[2]);
			Date d = new Date();
			String ngayht = dd.format(d);
			int namht = Integer.parseInt(ngayht.split("[/]")[2]);
			int tuoi = namht - namsinh;
			return tuoi;
		}
		
		public String toString() {
			return hoten + ";" + gioitinh + ";" + ngaysinh + ";"+ TinhTuoi();
		}
		
		
	}