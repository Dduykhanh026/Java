package Bean;

import java.util.Date;

public class SinhVienBean extends Nguoi {
	private String masv;
	private Double dtb;
		//Phát sinh 1 hàm tạo k tham số 
		
		//Phát sinh 1 hàm tạo 5 tham số
		//Hàm Get,set
		//Hàm toString()
	public SinhVienBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SinhVienBean(String masv, String hoten, boolean gioitinh, Date ngaysinh, double dtb) {
		super(hoten, gioitinh, ngaysinh);
		this.masv = masv;
		this.dtb = dtb;
	}
	public String getMasv() {
		return masv;
	}

	public void setMasv(String masv) {
		this.masv = masv;
	}

	public double getDtb() {
		return dtb;
	}

	public void setDtb(double dtb) {
		this.dtb = dtb;
	}

	
	public String toString() {
		return masv +";"+ super.toString() + ";" + dtb;
	}
		
		
}


