package Bean;

public class thongkebean {
	private boolean gioitinh;
	private int soluong;
	
	//Hàm get, set
	public boolean isgioitinh() {
		return gioitinh;
	}
	public void setgioitinh(boolean gioitinh) {
		this.gioitinh = gioitinh;
	}
	public int getSoluong() {
		return soluong;
	}
	public void setSoluong(int soluong) {
		this.soluong = soluong;
	}
	//Hàm toString
	public String toString() {
		return "gioitinh: " + gioitinh + " - soluong: " + soluong;
	}
	
	
	//Hàm khởi tạo có tham số & không tham số
	public thongkebean(boolean gioitinh, int soluong) {
		super();
		this.gioitinh = gioitinh;
		this.soluong = soluong;
	}
	public thongkebean() {
		super();
		
	}
	
	
}
