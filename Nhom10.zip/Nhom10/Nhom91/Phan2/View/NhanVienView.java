package View;

import Bean.NhanVienBean;
import Bean.SinhVienBean;
import Bo.NhanVienBo;
import Dao.KetNoiDao;

public class NhanVienView {

	public static void main(String[] args) {
		try {
			NhanVienBo nvbo = new NhanVienBo();
			nvbo.ketnoi();
			System.out.println("Danh sách nhân viên: ");
			nvbo.HienThi();
			//Lưu file vào csdl
			nvbo.LuuCSDL("data.txt");
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
