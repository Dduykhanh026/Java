package View;

import Bean.SinhVienBean;
import Bo.SinhVienBo;

public class SinhVienView {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			SinhVienBo svbo = new SinhVienBo();
			System.out.println("Danh sách sinh viên: ");
			for(SinhVienBean sv : svbo.getsv())
				System.out.println(sv);
			System.out.println("TBC điểm trung bình: "+ svbo.TbcDtb());
			
		} catch (Exception e) {
			
		}
	}

}
