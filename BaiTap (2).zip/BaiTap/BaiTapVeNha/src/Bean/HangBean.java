package Bean;

import java.util.Date;

public class HangBean {
	// mã hàng, tên hàng, ngày nhập hàng, số lượng, giá
	private String mahang;
	private String tenhang;
	private Date ngaynhaphang;
	private int soluong;
	private double dongia;
	public HangBean() {
		super();
	}
	public HangBean(String mahang, String tenhang, Date ngaynhaphang, int soluong, double dongia) {
		super();
		this.mahang = mahang;
		this.tenhang = tenhang;
		this.ngaynhaphang = ngaynhaphang;
		this.soluong = soluong;
		this.dongia = dongia;
	}
	public String getMahang() {
		return mahang;
	}
	public void setMahang(String mahang) {
		this.mahang = mahang;
	}
	public String getTenhang() {
		return tenhang;
	}
	public void setTenhang(String tenhang) {
		this.tenhang = tenhang;
	}
	public Date getNgaynhaphang() {
		return ngaynhaphang;
	}
	public void setNgaynhaphang(Date ngaynhaphang) {
		this.ngaynhaphang = ngaynhaphang;
	}
	public int getSoluong() {
		return soluong;
	}
	public void setSoluong(int soluong) {
		this.soluong = soluong;
	}
	public double getDongia() {
		return dongia;
	}
	public void setDongia(Long dongia) {
		this.dongia = dongia;
	}
	
}
