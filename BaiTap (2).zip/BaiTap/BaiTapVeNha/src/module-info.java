/**
 * 
 */
/**
 * 
 */
module BaiTapVeNha {
	requires java.desktop;
	requires java.sql;
	requires java.naming;
}