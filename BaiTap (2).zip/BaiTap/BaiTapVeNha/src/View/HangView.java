package View;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import Bo.HangBo;
import Dao.KetNoiDao;

import javax.swing.JTabbedPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;

import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class HangView extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private JTextField txtmahang;
	private JTextField txttenhang;
	private JTextField txtngaynhaphang;
	private JTextField txtsoluong;
	private JTextField txtdongia;
	HangBo hb = new HangBo();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HangView frame = new HangView();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	ArrayList<String> ds = new ArrayList<String>();
	private JTable table_1;
	private JTextField txtmahangban;
	private JTextField txttenhangban;
	private JTextField txtsoluongban;
	private JTextField txttongtien;
	void NapBang(ArrayList<String> ds) {
		//Tạo mô hình
		DefaultTableModel mh = new DefaultTableModel();
		//Tạo cột
		mh.addColumn("Mã hàng"); 
		mh.addColumn("Tên hàng");
		mh.addColumn("Ngày nhập hàng");
		mh.addColumn("Số lượng");
		mh.addColumn("Giá");

		for(String h:ds) {
			String[] t = h.split("[;]");
			mh.addRow(t); //Không cần chia ra
		}
		//Đưa mô hình vào Jtable
		table.setModel(mh);
		
	}
	void NapBangBan(ArrayList<String> ds) {
		//Tạo mô hình
		DefaultTableModel b = new DefaultTableModel();
		//Tạo cột
		b.addColumn("Mã hàng"); 
		b.addColumn("Tên hàng");
		b.addColumn("Ngày nhập hàng");
		b.addColumn("Số lượng");
		b.addColumn("Giá");

		for(String h:ds) {
			String[] t = h.split("[;]");
			b.addRow(t); //Không cần chia ra
		}
		//Đưa mô hình vào Jtable
		table_1.setModel(b);
		
	}
	public HangView() {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowOpened(WindowEvent e) {
				HangBo hb = new HangBo();
				try {
					hb.KetNoi();
					String sql = "select * from Hang";
					PreparedStatement cmd = KetNoiDao.cn.prepareStatement(sql);
					ResultSet rs = cmd.executeQuery();
					while(rs.next()) {
						String h = rs.getString("mahang") + ";" +rs.getString("tenhang")+ ";" +rs.getDate("ngaynhaphang")+ ";" +rs.getInt("soluong")+ ";" +rs.getFloat("gia");
						ds.add(h);
					}
					NapBang(ds);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 690, 758);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(22, 145, 537, 362);
		contentPane.add(tabbedPane);
		
		JScrollPane scrollPane = new JScrollPane();
		tabbedPane.addTab("New tab", null, scrollPane, null);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int d = table.getSelectedRow();
				String mahang = table.getValueAt(d, 0).toString();
				txtmahang.setText(mahang);
				String tenhang = table.getValueAt(d, 1).toString();
				txttenhang.setText(tenhang);
				String ngaynhaphang = table.getValueAt(d, 2).toString();
				txtngaynhaphang.setText(ngaynhaphang);
				String soluong  = table.getValueAt(d, 3).toString();
				txtsoluong.setText(soluong);
				String gia = table.getValueAt(d, 4).toString();
				txtdongia.setText(gia);
				
				String mahangban = table.getValueAt(d, 0).toString();
				txtmahangban.setText(mahang);
				String tenhangban = table.getValueAt(d, 1).toString();
				txttenhangban.setText(tenhang);
				
				int soluongban = Integer.parseInt(txtsoluongban.getText());
				txtsoluongban.setText(String.valueOf(soluongban));
					
			}
		});
		scrollPane.setViewportView(table);
		
		JButton btnNewButton = new JButton("THÊM");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					//Them(String mahang, String tenhang, Date ngaynhaphang, int soluong, Long gia)
					String mahang = txtmahang.getText();
					String tenhang = txttenhang.getText();
					SimpleDateFormat dd = new SimpleDateFormat("dd/MM/yyyy");
					String ngaynhaphang =txtngaynhaphang.getText();
					int soluong = Integer.parseInt(txtsoluong.getText());
					double gia = Double.parseDouble(txtdongia.getText());
					hb.Them(mahang, tenhang, ngaynhaphang, soluong, gia);//Thêm vào csdl
					String h = mahang+ ";" +tenhang+";"+txtngaynhaphang.getText()+";"+txtsoluong.getText()+";"+txtdongia.getText();
					ds.add(h);
					NapBang(ds);
				} catch (Exception e1) {
					e1.printStackTrace();
				} 
				
			}
		});
		btnNewButton.setBounds(569, 249, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("XÓA");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String key = txttenhang.getText();
				try {
					int n = JOptionPane.showConfirmDialog(null, "Xác nhận xóa?");
					hb.KetNoi();
					for(String h: ds) {
						String[] t = h.split("[;]");
						if(t[1].equals(key)) {
							ds.remove(h);
							hb.Xoa(key);
							JOptionPane.showMessageDialog(null,"Đã xóa!");
							break;
						}
					}
					NapBang(ds);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_1.setBounds(569, 283, 89, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("SỬA");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					String key = txttenhang.getText();
					String h = txttenhang.getText() + ";" +
							txtmahang.getText() + ";" +
							txtngaynhaphang.getText() + ";" +
							txtsoluong.getText() + ";" +
							txtdongia.getText();
					String mahang = txtmahang.getText();
					String tenhang = txttenhang.getText();
					int soluong = Integer.parseInt(txtsoluong.getText());
					double gia = Double.parseDouble(txtdongia.getText());
					int m = hb.Sua(mahang, tenhang, soluong, gia);
					if(m == 0)
						JOptionPane.showInternalMessageDialog(null, "Không tìm thấy mặt hàng!");
					
					int n = ds.size();
//					for(int i = 0; i<n; i++) {
//						String s = ds.get(i);
//						String[] t = s.split("[;]");
//						if(t[1].equals(key))
//							ds.set(i, h);
//						break;
//					}
					NapBang(ds);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_2.setBounds(569, 317, 89, 23);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("TÌM KIẾM");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ArrayList<String> tam = new ArrayList<String>();
				String key = JOptionPane.showInputDialog("Nhập từ khóa!");
				for(String h: ds) {
					String[] t = h.split("[;]");
					if(t[0].toLowerCase().contains(key.toLowerCase())||
							t[1].toLowerCase().contains(key.toLowerCase())) 
						tam.add(h);
				}
				NapBang(tam);
			}
		});
		btnNewButton_3.setBounds(569, 351, 89, 23);
		contentPane.add(btnNewButton_3);
		
		JLabel lblNewLabel = new JLabel("Mã hàng");
		lblNewLabel.setBounds(22, 11, 66, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Tên hàng");
		lblNewLabel_1.setBounds(125, 11, 89, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Ngày nhập hàng");
		lblNewLabel_2.setBounds(304, 11, 95, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Số lượng");
		lblNewLabel_3.setBounds(422, 11, 54, 14);
		contentPane.add(lblNewLabel_3);
		JLabel lblNewLabel_4 = new JLabel("Đơn giá");
		lblNewLabel_4.setBounds(517, 11, 46, 14);
		contentPane.add(lblNewLabel_4);
		
		
		txtmahang = new JTextField();
		txtmahang.setBounds(22, 36, 86, 20);
		contentPane.add(txtmahang);
		txtmahang.setColumns(10);
		
		txttenhang = new JTextField();
		txttenhang.setBounds(125, 36, 171, 20);
		contentPane.add(txttenhang);
		txttenhang.setColumns(10);
		
		txtngaynhaphang = new JTextField();
		txtngaynhaphang.setBounds(304, 36, 86, 20);
		contentPane.add(txtngaynhaphang);
		txtngaynhaphang.setColumns(10);
		
		txtsoluong = new JTextField();
		txtsoluong.setBounds(422, 36, 54, 20);
		contentPane.add(txtsoluong);
		txtsoluong.setColumns(10);
		
		txtdongia = new JTextField();
		txtdongia.setBounds(517, 36, 110, 20);
		contentPane.add(txtdongia);
		txtdongia.setColumns(10);
		
		JButton btnNewButton_4 = new JButton("BÁN HÀNG");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ArrayList<String> ban = new ArrayList<String>();
				for(String h: ds) {
					String[] t = h.split("[;]");
					if(t[1].toLowerCase().contains(txttenhang.getText().toLowerCase()))			 
						ban.add(h);
				}
				NapBangBan(ban);
			}
		});
		btnNewButton_4.setBounds(527, 75, 110, 37);
		contentPane.add(btnNewButton_4);
		
		JTabbedPane tabbedPane_1 = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane_1.setBounds(22, 539, 537, 158);
		contentPane.add(tabbedPane_1);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		tabbedPane_1.addTab("New tab", null, scrollPane_1, null);
		
		table_1 = new JTable();
		///
		scrollPane_1.setViewportView(table_1);
		
		JLabel lblNewLabel_5 = new JLabel("DANH SÁCH HÀNG ĐÃ BÁN");
		lblNewLabel_5.setBounds(22, 518, 193, 14);
		contentPane.add(lblNewLabel_5);
		
		txtmahangban = new JTextField();
		txtmahangban.setBounds(22, 83, 86, 20);
		contentPane.add(txtmahangban);
		txtmahangban.setColumns(10);
		
		txttenhangban = new JTextField();
		txttenhangban.setBounds(125, 83, 171, 20);
		contentPane.add(txttenhangban);
		txttenhangban.setColumns(10);
		
		txtsoluongban = new JTextField();
		txtsoluongban.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				double TongTien = Integer.parseInt(txtsoluongban.getText()) * Double.parseDouble(txtdongia.getText());
				txttongtien.setText(String.valueOf(TongTien));
			}
		});
		txtsoluongban.setBounds(306, 83, 54, 20);
		contentPane.add(txtsoluongban);
		txtsoluongban.setColumns(10);
		
		txttongtien = new JTextField();
		txttongtien.setBounds(370, 82, 145, 23);
		contentPane.add(txttongtien);
		txttongtien.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("Tổng Tiền");
		lblNewLabel_6.setBounds(373, 67, 66, 14);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Mã hàng");
		lblNewLabel_7.setBounds(22, 67, 66, 14);
		contentPane.add(lblNewLabel_7);
		
		JLabel lblNewLabel_1_1 = new JLabel("Tên hàng");
		lblNewLabel_1_1.setBounds(125, 67, 89, 14);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_3_1 = new JLabel("Số lượng");
		lblNewLabel_3_1.setBounds(304, 67, 54, 14);
		contentPane.add(lblNewLabel_3_1);
	}
}
