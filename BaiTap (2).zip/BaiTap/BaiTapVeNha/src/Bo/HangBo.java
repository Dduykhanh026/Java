package Bo;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import Bean.HangBean;
import Dao.HangDao;
import Dao.KetNoiDao;

public class HangBo {
	ArrayList<HangBean> ds;
	HangDao hdao = new HangDao();
	KetNoiDao kndao = new KetNoiDao();
	public void KetNoi() throws Exception {
		kndao.KetNoi();
	}

	public int Them(String mahang, String tenhang, String ngaynhaphang, int soluong, double gia) throws Exception {
		return kndao.Them(mahang, tenhang, ngaynhaphang, soluong, gia);
	}
	public void LuuCSDL(String tf) throws Exception{
		kndao.LuuCSDL(tf);
	}
	public void TimKiem(String key) throws Exception {
		hdao.TimKiem(key);
	}
	public int Xoa(String tenhang) throws Exception {
		return hdao.Xoa(tenhang);
	}
	public int Sua(String mahang, String tenhang, int soluong, double dongia) throws Exception {
		return hdao.Sua(mahang, tenhang, soluong, dongia);
	}
	public ArrayList<String> getds() throws Exception {	
		return kndao.getds();
	}
}
