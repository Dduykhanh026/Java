package Dao;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import Bean.HangBean;

public class HangDao {
	//TÌM KIẾM
		public ArrayList<String> TimKiem(String key) throws Exception {
			ArrayList<String> ds = new ArrayList<String>();
			String sql = "select * from Hang where tenhang like ?";
			//b3 Tạo câu lệnh PrepareStatement
			PreparedStatement cmd = KetNoiDao.cn.prepareStatement(sql);
			//b4 Truyền tham số vào câu lệnh sql nếu có
			cmd.setString(1,"%" + key + "%");
			//b5 Thực hiện câu lệnh
			ResultSet rs =cmd.executeQuery();
			//Duyệt rs
			while(rs.next()) {
//				System.out.println(rs.getString("mahang"));
//				System.out.println(rs.getString("tenhang"));
//				System.out.println(rs.getDate("ngaynhaphang"));
//				System.out.println(rs.getInt("soluong"));
//				System.out.println(rs.getFloat("gia"));
				String h = rs.getString("mahang") + ";" + rs.getString("tenhang") + ";" + rs.getDate("ngaynhaphang") + ";" + rs.getInt("soluong")+ ";" + rs.getFloat("gia");
				ds.add(h);
			}
			//Đóng file
			rs.close();
			return ds;
		}
		public int Xoa(String tenhang) throws Exception {
			//Tao cau lệnh sql
			String sql  = "delete from Hang where tenhang = ?";
			//b3 Tạo câu lênj PrepareStatement
			PreparedStatement cmd = KetNoiDao.cn.prepareStatement(sql);
			cmd.setString(1, tenhang);
			return cmd.executeUpdate();//Thực thi câu lệnh
		}
		public int Sua(String mahang, String tenhang, int soluong, double gia) throws Exception {
			//Tao cau lệnh sql
			String sql  = "update Hang set mahang=? tenhang=?  soluong=? gia=? where tenhang = ?";
			//b3 Tạo câu lênj PrepareStatement
			PreparedStatement cmd = KetNoiDao.cn.prepareStatement(sql);
			cmd.setString(1, mahang);
			cmd.setString(2, tenhang);
			cmd.setInt(3, soluong);
			cmd.setDouble(4, gia);
			cmd.setString(5, mahang);
			return cmd.executeUpdate();//Thực thi câu lệnh
		}
		
		
	public static void main(String[] args) {
		
	}

}
