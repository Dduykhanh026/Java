package Dao;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.util.Date;


import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;


public class KetNoiDao {
	public static Connection cn;
	ArrayList<String> ds = new ArrayList<String>();
	//KẾT NỐI
	public void KetNoi() throws Exception {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		System.out.println("Đã xác định hệ QTCSDL!");
		cn = DriverManager.getConnection("jdbc:sqlserver://LAB405-53:1433;databaseName=BaiTap; user=sa; password=123");
		System.out.println("Đã kết nối!");
	}
	//HIỂN THỊ
	public void HienThi() throws Exception {
		//Lấy dữ liệu về
		String sql = "select * from Hang";
		//Tạo câu lệnh PreparedStatement
		PreparedStatement cmd = KetNoiDao.cn.prepareStatement(sql);
		//Truyền tham số nếu có
		//Thực hiện cmd
		ResultSet rs = cmd.executeQuery();
		while(rs.next()) {
			System.out.println(rs.getString("mahang"));
			System.out.println(rs.getString("tenhang"));
			System.out.println(rs.getDate("ngaynhaphang"));
			System.out.println(rs.getInt("soluong"));
			System.out.println(rs.getFloat("gia"));
		}
		rs.close();
	}
	public void DocFile() {
		try {
			ArrayList<String> ds = new ArrayList<String>();
			FileReader f = new FileReader("hang.txt");
			BufferedReader bd = new BufferedReader(f);
			while(true) {
				String st = bd.readLine();
				if(st == null || st =="") break;
				System.out.println(st);		
				ds.add(st);
			}
			bd.close();
		}catch (Exception tt) {
			tt.printStackTrace();
		}
	}
	
	public ArrayList<String> getds() throws Exception{
		
		try {
			FileReader f = new FileReader("hang.txt");
			BufferedReader bd = new BufferedReader(f);
			while(true) {
				String st = bd.readLine();
				if(st == null || st =="") break;
				System.out.println(st);		
				ds.add(st);
			}
			bd.close();
			return ds;
		}catch (Exception tt) {
			tt.printStackTrace();
		}
		return ds;
	}
	public boolean ktma(String tenhang) throws Exception {
		//b2 Lấy dl về
		String sql = "select * from Hang where tenhang = ?";
		//b3 Tạo câu lệnh PrepareStatement
		PreparedStatement cmd = KetNoiDao.cn.prepareStatement(sql);
		//b4 Truyền tham số vào câu lệnh sql nếu có
		cmd.setString(1, tenhang);
		//b5 Thực hiện câu lệnh
		ResultSet rs =cmd.executeQuery();
		boolean kq = rs.next();
		rs.close();
		return kq;
	}
	public int Them(String mahang, String tenhang, String ngaynhaphang, int soluong, double gia) throws Exception {
		//Tao cau lệnh sql
		if(ktma(mahang) == true) return 0;//Trả về true nếu mã nhân viên đó đã tồn tại
		String sql  = "insert into Hang(mahang,tenhang,ngaynhaphang,soluong,gia) values(?,?,?,?,?)";
		//b3 Tạo câu lên PrepareStatement
		PreparedStatement cmd = KetNoiDao.cn.prepareStatement(sql);
		cmd.setString(1, mahang);
		cmd.setString(2, tenhang);
		//Đổi date của Util sang ngày sql
		SimpleDateFormat dd = new SimpleDateFormat("dd/MM/yyyy");
		cmd.setDate(3,new java.sql.Date(dd.parse(ngaynhaphang).getTime()));
		cmd.setInt(4, soluong);
		cmd.setDouble(5, gia);
		return cmd.executeUpdate();//Thực thi câu lệnh
	}
	
	public void LuuCSDL(String tf) throws Exception{
		FileReader f = new FileReader(tf);
		BufferedReader bd = new BufferedReader(f);
		while(true) {
			String st = bd.readLine();
			if(st == null || st =="") break;
			String[] t = st.split("[;]");
			String mahang = t[0];
			String tenhang = t[1];
			String ngaynhaphang  = t[2];
			int soluong = Integer.parseInt(t[3]);
			long gia = Long.parseLong(t[4]);
			Them(mahang, tenhang, ngaynhaphang, soluong, gia);
		}
		System.out.println("Đã lưu vào CSDL!");
		bd.close();
	}
	//HÀM MAIN CHẠY THỬ
	public static void main(String[] args) {
		try {
			HangDao hdao = new HangDao();
			KetNoiDao kndao = new KetNoiDao();
			kndao.KetNoi();
			kndao.DocFile();
			kndao.Them("mh1", "banh xe", "12/01/2004", 331,21312);
			kndao.LuuCSDL("hang.txt");
			hdao.TimKiem("Xăng");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


}


