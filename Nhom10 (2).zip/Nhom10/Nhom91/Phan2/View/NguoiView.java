package View;

import java.util.ArrayList;

import Bean.Nguoi;
import Bean.thongkebean;
import Bo.NguoiBo;

public class NguoiView {
	public static void main(String[] args) {
		try {
			NguoiBo nbo = new NguoiBo();
			ArrayList<Nguoi> ds = nbo.getds();
			System.out.println("Danh sách: ");
			nbo.HienThi();
			System.out.println("Danh sách những người trên 30 tuổi: ");
			for(Nguoi n: nbo.getdstheotuoi(30)) {
				System.out.println(n.toString());
			}
			System.out.println("Thống kê nam nữ: ");
			for(thongkebean tk : nbo.thongke()) {
				System.out.println(tk.toString());
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
