package Bean;

import java.util.Date;

public class NhanVienBean extends Nguoi {
	private String manv;
	private String email;
	private String sodt;
	private double hsl;
	public NhanVienBean() {
		super();
		
	}
	public NhanVienBean(String manv, String hoten, boolean gioitinh, Date ngaysinh,  String email, String sodt, double hsl) {
		super(hoten, gioitinh, ngaysinh);
		this.manv = manv;
		this.email = email;
		this.sodt = sodt;
		this.hsl = hsl;
	}
	public String getManv() {
		return manv;
	}
	public void setManv(String manv) {
		this.manv = manv;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSodt() {
		return sodt;
	}
	public void setSodt(String sodt) {
		this.sodt = sodt;
	}
	public double getHsl() {
		return hsl;
	}
	public void setHsl(double hsl) {
		this.hsl = hsl;
	}
	@Override
	public String toString() {
		return manv + ";" + super.toString() + ";" + email + ";" + sodt + ";" + hsl;
	}
	
}
