package Bean;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class Chay2 {
	public static void main(String[] args) {
		try {
		SimpleDateFormat dd = new SimpleDateFormat("dd/MM/yyyy");
		
		Nguoi n1 = new Nguoi("Đào Duy Khánh", true, dd.parse("12/08/1993"));
		Nguoi n2 = new Nguoi("Ngô Thị Thanh Nhàn", false, dd.parse("29/03/2004"));
		Nguoi n3 = new Nguoi("Nguyễn Thị Huyền Trân", false, dd.parse("24/10/2004"));
		//Tạo 2 nhân viên và hiển thị
		NhanVienBean nv1 = new NhanVienBean("nv-01", "Nguyễn Hữu Đạt", true, dd.parse("02/10/2003"), "dnguyenhuu@gmail.com", "0123456789", 4.8);
		NhanVienBean nv2 = new NhanVienBean("nv-02", "Nguyễn Công Thành", true, dd.parse("02/01/2004"), "nguyenthanhcong@gmail.com", "0123456789", 4.5);
//		System.out.println(nv1.toString());
//		System.out.println(nv2.toString());
		
		//Tạo 2 sinh viên và hiển thị
		SinhVienBean sv1 = new SinhVienBean("sv-01","Đỗ Tiến Mạnh", false, dd.parse("10/07/2004"), 2.1);
		SinhVienBean sv2 = new SinhVienBean("sv-02", "Lê Phi Hưng", true, dd.parse("01/01/2004"), 8.9);
//		System.out.println(sv1.toString());
//		System.out.println(sv2.toString());
		
		ArrayList<Nguoi> ds = new ArrayList<Nguoi>();
		ds.add(n1);
		ds.add(n2);
		ds.add(n3);
		ds.add(nv1);
		ds.add(nv2);
		ds.add(sv1);
		ds.add(sv2);
		System.out.println("Danh sách người:");
		//IN RA DANH SÁCH NGƯỜI K PHẢI LÀ SINH VIÊN HAY NHÂN VIÊN
		for(Nguoi n:ds) {
			if (!(n instanceof NhanVienBean) && !(n instanceof SinhVienBean)) {
				System.out.println(n.toString());
			}
		}
		//DANH SÁCH NHÂN VIÊN
		System.out.println("Danh sách nhân viên: ");
		for(Nguoi n:ds) {
			if (n instanceof NhanVienBean) {
				System.out.println(n.toString());
			}
		}
		//DANH SÁCH SINH VIÊN
		System.out.println("Danh sách sinh viên: ");
		for(Nguoi n:ds) {
			if (n instanceof SinhVienBean) {
				System.out.println(n.toString());
			}
		}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
