package Bo;


import java.util.ArrayList;

import Bean.Nguoi;
import Bean.SinhVienBean;
import Bean.thongkebean;
import Dao.NguoiDao;

public class NguoiBo {
	
	NguoiDao ndao = new NguoiDao();//Câu lệnh quan trọng phải có
	ArrayList<Nguoi>ds;
	public ArrayList<Nguoi> getds() throws Exception {
		ds = ndao.getds();
		return ds;
	}
	public void HienThi() throws Exception {
		for(Nguoi person:ds) {
			System.out.println(person.toString());
		}
	}
	public ArrayList<Nguoi> getdstheotuoi(int tuoi){
		ArrayList<Nguoi> tam = new ArrayList<Nguoi>();
		for(Nguoi person:ds) {
			if(person.TinhTuoi() >tuoi )
				System.out.println(person.toString());
		}
		return tam;
	}
	//Thống kê nam nữ
	public ArrayList<thongkebean> thongke() throws Exception {
		ArrayList<thongkebean> tam = new ArrayList<thongkebean>();
		int dem = 0;
		for(Nguoi n: ds)
			if (n.isGioitinh()==true)
				dem++;
		tam.add(new thongkebean(true, dem));
		tam.add(new thongkebean(false, ds.size()-dem));
		return tam;
	}
	//
	
	}
