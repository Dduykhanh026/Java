package Bo;

import java.util.ArrayList;
import java.util.Date;

import Bean.NhanVienBean;
import Dao.KetNoiDao;
import Dao.NhanVienDao;

public class NhanVienBo {
//	NguoiDao ndao = new NguoiDao();
//	ArrayList<NhanVienBean> ds = new ArrayList<NhanVienBean>();
//	public ArrayList<NhanVienBean> getnv() throws Exception{
//		ds = ndao.getnv();
//		return ds;
//	}
	public ArrayList<NhanVienBean> ds;
	NhanVienDao nvdao = new NhanVienDao();
	KetNoiDao kndao = new KetNoiDao();
	public void HienThi() throws Exception{
		kndao.HienThi();
	}
	public void ketnoi() throws Exception {
		kndao.ketnoi();
	}
	public ArrayList<NhanVienBean> getnv() throws Exception {
		ds = nvdao.getnv();
		return ds;
	}
	public int Xoa(String manv) throws Exception {
		for(NhanVienBean nv: ds) {
			if(nv.getManv().equals(manv)) {
				ds.remove(nv);//Xóa trong bộ nhớ
				nvdao.Xoa(manv); //Xóa trong CSDL
			}
		}
		return 0;
	}
	public int Sua(String manv,double hsl) throws Exception {
		return nvdao.Sua(manv, hsl);
	}
	public int Them(String manv, String hoten, boolean gioitinh, Date ngaysinh,  String email, String sodt, double hsl) throws Exception {
		return nvdao.Them(manv, hoten, gioitinh, ngaysinh, email, sodt, hsl);
	}
	public void LuuCSDL(String tf) throws Exception{
		nvdao.LuuCSDL(tf);
	}
}
