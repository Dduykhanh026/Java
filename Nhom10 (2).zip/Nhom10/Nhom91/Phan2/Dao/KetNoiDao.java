package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class KetNoiDao {
	public static Connection cn;
	public void ketnoi() throws Exception{
		//b1 Xác định hệ quản trị cơ sở dữ liệu
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		System.out.println("Đã xác định hệ QTCSDL!");
		//b2 Kết nối với hệ QTCSDL
		cn = DriverManager.getConnection("jdbc:sqlserver://LAB405-14:1433;databaseName=Nhom9; user=sa; password=123");
		System.out.println("Đã kết nối!");
	}
	public void HienThi() throws Exception {
		//b2 Lấy dl về
		String sql = "select * from nhanvien";
		//b3 Tạo câu lệnh PrepareStatement
		PreparedStatement cmd = KetNoiDao.cn.prepareStatement(sql);
		//b4 Truyền tham số vào câu lệnh sql nếu có
		//b5 Thực hiện câu lệnh
		ResultSet rs =cmd.executeQuery();
		//Duyệt rs
		while(rs.next()) {
			System.out.println(rs.getString("manv"));
			System.out.println(rs.getString("hoten"));
			System.out.println(rs.getBoolean("gioitinh"));
			System.out.println(rs.getDate("ngaysinh"));
			System.out.println(rs.getDouble("hsl"));
			System.out.println("------");
		}
		//Đóng file
		rs.close();
	}
	public void TimKiem(String key) throws Exception {
		//b2 Lấy dl về
				String sql = "select * from nhanvien where hoten like ?";
				//b3 Tạo câu lệnh PrepareStatement
				PreparedStatement cmd = KetNoiDao.cn.prepareStatement(sql);
				//b4 Truyền tham số vào câu lệnh sql nếu có
				cmd.setString(1,"%" + key + "%");
				//b5 Thực hiện câu lệnh
				ResultSet rs =cmd.executeQuery();
				//Duyệt rs
				while(rs.next()) {
					System.out.println(rs.getString("manv"));
					System.out.println(rs.getString("hoten"));
					System.out.println(rs.getBoolean("gioitinh"));
					System.out.println(rs.getDate("ngaysinh"));
					System.out.println(rs.getDouble("hsl"));
					System.out.println("------");
				}
				//Đóng file
				rs.close();
	}
	
	public static void main(String[] args) {
		try {
			//b1 Kết nối
			KetNoiDao kndao  = new KetNoiDao();
			kndao.ketnoi();
			kndao.HienThi();
			kndao.TimKiem("Dao Duy Khanh");
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
