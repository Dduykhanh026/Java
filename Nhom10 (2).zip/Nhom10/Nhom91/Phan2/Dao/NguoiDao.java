package Dao;
import java.text.SimpleDateFormat;
import java.util.ArrayList;


import Bean.Nguoi;
import Bean.NhanVienBean;
import Bean.SinhVienBean;

public class NguoiDao {
	
	public ArrayList<Nguoi> getds() throws Exception {
		SimpleDateFormat dd = new SimpleDateFormat("dd/MM/yyyy");
		
		Nguoi n1 = new Nguoi("Đào Duy Khánh", true, dd.parse("12/08/1993"));
		Nguoi n2 = new Nguoi("Ngô Thị Thanh Nhàn", false, dd.parse("29/03/2004"));
		Nguoi n3 = new Nguoi("Nguyễn Thị Huyền Trân", false, dd.parse("24/10/2004"));
		//Tạo 2 nhân viên và hiển thị
		NhanVienBean nv1 = new NhanVienBean("nv-01", "Nguyễn Hữu Đạt", true, dd.parse("02/10/2003"), "dnguyenhuu@gmail.com", "0123456789", 4.8);
		NhanVienBean nv2 = new NhanVienBean("nv-02", "Nguyễn Công Thành", true, dd.parse("02/01/2004"), "nguyenthanhcong@gmail.com", "0123456789", 4.5);
//		System.out.println(nv1.toString());
//		System.out.println(nv2.toString());
		
		//Tạo 2 sinh viên và hiển thị
		SinhVienBean sv1 = new SinhVienBean("sv-01","Đỗ Tiến Mạnh", false, dd.parse("10/07/2004"), 2.1);
		SinhVienBean sv2 = new SinhVienBean("sv-02", "Lê Phi Hưng", true, dd.parse("01/01/2004"), 8.9);
//		System.out.println(sv1.toString());
//		System.out.println(sv2.toString());
		
		ArrayList<Nguoi> ds = new ArrayList<Nguoi>();
		ds.add(n1);
		ds.add(n2);
		ds.add(n3);
		ds.add(nv1);
		ds.add(nv2);
		ds.add(sv1);
		ds.add(sv2);
		return ds;
	}
	public ArrayList<SinhVienBean> getsv() throws Exception{
		ArrayList<SinhVienBean>  tam = new ArrayList<SinhVienBean>();
		for(Nguoi n: getds())
			if(n instanceof SinhVienBean) {
				SinhVienBean sv = (SinhVienBean)n;
				tam.add(sv);
			}
		return tam;
	}
	public ArrayList<NhanVienBean> getnv() throws Exception{
		ArrayList<NhanVienBean>  tam = new ArrayList<NhanVienBean>();
		for(Nguoi n: getds())
			if(n instanceof NhanVienBean) {
				NhanVienBean nv = (NhanVienBean)n;
				tam.add(nv);
			}
		return tam;
	}
}
