package Dao;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import Bean.NhanVienBean;

public class NhanVienDao {
	public ArrayList<NhanVienBean> getnv() throws Exception {
		ArrayList<NhanVienBean> ds  = new ArrayList<NhanVienBean>();
		//b2 Lấy dl về
		String sql = "select * from nhanvien";
		//b3 Tạo câu lệnh PrepareStatement
		PreparedStatement cmd = KetNoiDao.cn.prepareStatement(sql);
		//b4 Truyền tham số vào câu lệnh sql nếu có
		//b5 Thực hiện câu lệnh  
		ResultSet rs =cmd.executeQuery();
		//Duyệt rs
		while(rs.next()) {
//			System.out.println(rs.getString("manv"));
//			System.out.println(rs.getString("hoten"));
//			System.out.println(rs.getBoolean("gioitinh"));
//			System.out.println(rs.getDate("ngaysinh"));
//			System.out.println(rs.getDouble("hsl"));
//			System.out.println("------");
			String manv = rs.getString("manv");
			String hoten = rs.getString("hoten");
			boolean gioitinh = rs.getBoolean("gioitinh");
			Date ngaysinh = rs.getDate("ngaysinh");
			String email = rs.getString("email");
			String sodt = rs.getString("sodt");
			double hsl = rs.getDouble("hsl");
			NhanVienBean nv = new NhanVienBean(manv, hoten, gioitinh, ngaysinh, email, sodt, hsl);
			ds.add(nv);
		}
		//Đóng file
		rs.close();
		return ds;
	}
	public int Xoa(String manv) throws Exception {
		//Tao cau lệnh sql
		String sql  = "delete from nhanvien where manv = ?";
		//b3 Tạo câu lênj PrepareStatement
		PreparedStatement cmd = KetNoiDao.cn.prepareStatement(sql);
		cmd.setString(1, manv);
		
		return cmd.executeUpdate();//Thực thi câu lệnh
	}
	public int Sua(String manv,double hsl) throws Exception {
		//Tao cau lệnh sql
		String sql  = "update nhanvien set hsl=hsl + ? where manv = ?";
		//b3 Tạo câu lênj PrepareStatement
		PreparedStatement cmd = KetNoiDao.cn.prepareStatement(sql);
		cmd.setDouble(1, hsl);
		cmd.setString(2, manv);
		return cmd.executeUpdate();//Thực thi câu lệnh
	}
	public boolean ktma(String manv) throws Exception {
		//b2 Lấy dl về
		String sql = "select * from nhanvien where manv = ?";
		//b3 Tạo câu lệnh PrepareStatement
		PreparedStatement cmd = KetNoiDao.cn.prepareStatement(sql);
		//b4 Truyền tham số vào câu lệnh sql nếu có
		cmd.setString(1, manv);
		//b5 Thực hiện câu lệnh
		ResultSet rs =cmd.executeQuery();
		boolean kq = rs.next();
		rs.close();
		return kq;
	}
	public int Them(String manv, String hoten, boolean gioitinh, Date ngaysinh,  String email, String sodt, double hsl) throws Exception {
		//Tao cau lệnh sql
		if(ktma(manv) == true) return 0;//Trả về true nếu mã nhân viên đó đã tồn tại
		String sql  = "insert into nhanvien(manv,hoten,gioitinh,ngaysinh,email,sodt,hsl) values(?,?,?,?,?,?,?)";
		//b3 Tạo câu lên PrepareStatement
		PreparedStatement cmd = KetNoiDao.cn.prepareStatement(sql);
		cmd.setString(1, manv);
		cmd.setString(2, hoten);
		cmd.setBoolean(3, gioitinh);
		//Đổi date của Util sang ngày sql
		cmd.setDate(4,new java.sql.Date(ngaysinh.getTime()));
		cmd.setString(5, email);
		cmd.setString(6, sodt);
		cmd.setDouble(7, hsl);
		return cmd.executeUpdate();//Thực thi câu lệnh
	}
	public void LuuCSDL(String tf) throws Exception{
		FileReader f = new FileReader(tf);
		BufferedReader bd = new BufferedReader(f);
		while(true) {//
			String st = bd.readLine();
			if(st == null || st =="") break;
			String[] t = st.split("[,]");
			String manv = t[0];
			String hoten = t[1];
			boolean gioitinh = Boolean.parseBoolean(t[2]);
			SimpleDateFormat dd = new SimpleDateFormat("dd/MM/yyyy");
			Date ngaysinh  = dd.parse(t[3]);
			double hsl = Double.parseDouble(t[4]);
			String email = t[5];
			String sodt = t[6];
			Them(manv, hoten, gioitinh, ngaysinh, email, sodt, hsl);
		}
		System.out.println("Đã lưu vào CSDL!");
		bd.close();
	}
	public static void main(String[] args) {
		try {
			NhanVienDao nvdao = new NhanVienDao();
			KetNoiDao kndao = new KetNoiDao();
			kndao.ketnoi();
			
//			System.out.println("Danh sách:");
//			for(NhanVienBean nv: nvdao.getnv()) {
//				System.out.println(nv);
//			}
			
//			System.out.println("Sau khi sửa:");
//			nvdao.Sua("nv2", 4.0);
//			for(NhanVienBean nv: nvdao.getnv()) {
//				System.out.println(nv);
//			}
			
//			System.out.println("Sau khi thêm");
//			SimpleDateFormat dd = new SimpleDateFormat("dd/MM/yyyy");
//			Date ngaysinh = dd.parse("12/08/2004");
//			nvdao.Them("nv15", "Dao Duy Khanh", true,  ngaysinh, "Dduykhanh026@gmail.com", "0763658573", 5.2);
//			for(NhanVienBean nv: nvdao.getnv()) {
//				System.out.println(nv);
//			}

//			System.out.println("Sau khi sửa:");
//			for(NhanVienBean nv: nvdao.getnv()) {
//				System.out.println(nv);
//			}
			nvdao.Xoa("m1");
			nvdao.Xoa("m2");
			nvdao.Xoa("m3");
			nvdao.Xoa("m4");
			nvdao.Xoa("m5");
			nvdao.LuuCSDL("data.txt");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}


}
