/**
 * 
 */
/**
 * 
 */
module Nhom91 {
	requires java.desktop;
	requires java.sql;
}